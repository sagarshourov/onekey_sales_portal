<h2>Your submitted information is rejected due certain reasons.</h2>

<div>You need to add valid information.</div>