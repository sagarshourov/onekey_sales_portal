<h2>New Document Uploaded</h2>
<table class="table">
    <tr>
        <td>Name :</td>
        <td>{{ $user->first_name }}</td>
    </tr>
    <tr>
        <td>Email :</td>
        <td>{{ $user->email }}</td>
    </tr>
    <tr>
        <td>Document Title :</td>
        <td>{{ $title }}</td>
    </tr>


</table>