<h2>Your submitted information is approved. Please find following details.</h2>
<small>Please keep this info secure.</small>
<table class="table">
    <tr>
        <td>Name :</td>
        <td>{{ $name }}</td>
    </tr>
    <tr>
        <td>Email :</td>
        <td>{{ $email }}</td>
    </tr>
    <tr>
        <td>Password :</td>
        <td>{{ $password }}</td>
    </tr>
    <tr>
        <td>Click below to login :</td>
        <td><a href="https://onekeycrm.us/login">Login</a> Or https://onekeycrm.us/login</td>
    </tr>
</table>