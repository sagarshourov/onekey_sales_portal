<h2>User requested for login. please find following details.</h2>
<table class="table">
    <tr>
        <td>Name :</td>
        <td>{{ $user->first_name }}</td>
    </tr>
    <tr>
        <td>Email :</td>
        <td>{{ $user->email }}</td>
    </tr>
    <tr>
        <td>Click below to view form :</td>
 
    </tr>
</table>