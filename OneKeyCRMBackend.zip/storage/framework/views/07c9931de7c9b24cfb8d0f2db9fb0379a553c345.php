<h1>Resest Your Passsword !</h1>

<p>Follow the link bellow for reset password ! </p>
<table class="table">
    <tr>
        <td><a href=<?php echo e($link); ?> style="box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol';border-radius:4px;color:#fff;display:inline-block;overflow:hidden;text-decoration:none;background-color:#2d3748;border-bottom:8px solid #2d3748;border-left:18px solid #2d3748;border-right:18px solid #2d3748;border-top:8px solid #2d3748">Reset Pawword</a></td>

    </tr>
    <tr><?php echo e($link); ?></tr>
    <tr>
        <td>OneKeyCRM</td>
    </tr>
    
</table><?php /**PATH C:\xampp\htdocs\onekey_sales_portal\api\resources\views/email/forget_password.blade.php ENDPATH**/ ?>