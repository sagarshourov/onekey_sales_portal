<?php 

if(!function_exists('get_title_id')){


function get_title_id($data,$id){



    foreach($data as $array){
        if ($array['id'] == $id)
            return $array['title'];
    }
    return '';

}
}

?>



<table border="1">
    <thead>
        <tr>
            <th style="background-color:  #333cff; color:white;">First Name</th>
            <th style="background-color:  #333cff; color:white;">Last Name</th>
            <th style="background-color:  #333cff; color:white;">Phone</th>

            <th style="background-color:  #333cff; color:white;">Email</th>
            <th style="background-color:  #333cff; color:white;">Note</th>
            <th style="background-color:  #333cff; color:white;">AG</th>
            <th style="background-color:  #333cff; color:white;">Status</th>
            <th style="background-color:  #333cff; color:white;">Package</th>
            <th style="background-color:  #333cff; color:white;">Last Contact</th>
            <th style="background-color:  #333cff; color:white;">Age</th>
            <th style="background-color:  #333cff; color:white;">GPA</th>
            <th style="background-color:  #333cff; color:white;">Last Status</th>
            <th style="background-color:  #333cff; color:white;">Feedback</th>

        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $calls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$call): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="13" style="background-color: #FFFF00; height : 20px; padding:5em; text-align : center">
            <?php echo e(get_title_id($section,$key)); ?>


            </td>
        </tr>
        <?php $__currentLoopData = $call; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $call): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($call->first_name); ?>


            </td>
            <td>
                <?php echo e($call->last_name); ?>


            </td>
            <td>
                <?php echo e($call->phone_number); ?>


            </td>
            <td>
                <?php echo e($call->email); ?>


            </td>
            <td>
                <?php echo e($call->note); ?>


            </td>
            <td>
                <?php echo e($call->ag==0?'FALSE':'TRUE'); ?>


            </td>
            <td>
            
                <?php echo e(get_title_id($status,$call->status)); ?>

            </td>


            <td>
                <?php echo e(get_title_id($package,$call->package)); ?>




            </td>
            <td>
                <?php echo e($call->last_contact); ?>


            </td>

            <td>
                <?php echo e($call->age); ?>


            </td>


            <td>
                <?php echo e($call->gpa); ?>


            </td>

            <td>

                <?php echo e($call->last_status_notes); ?>

            </td>
            <td>
                <?php echo e($call->feedbacks); ?>

            </td>


        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\onekey_sales_portal\api\api\resources\views/call_view.blade.php ENDPATH**/ ?>